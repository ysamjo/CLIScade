module.exports = {
  transport: 'pty'
};
